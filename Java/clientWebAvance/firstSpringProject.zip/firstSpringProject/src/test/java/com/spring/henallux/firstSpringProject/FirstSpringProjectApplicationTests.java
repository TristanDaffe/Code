package com.spring.henallux.firstSpringProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
